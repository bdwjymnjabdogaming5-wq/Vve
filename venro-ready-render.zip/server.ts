import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import cors from "cors";
import bodyParser from "body-parser";
import axios from "axios";
import { makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, DisconnectReason, downloadMediaMessage, jidNormalizedUser } from "@whiskeysockets/baileys";
import pino from "pino";
import Database from "better-sqlite3";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("bot_data.db");

// Initialize DB
db.exec(`
  CREATE TABLE IF NOT EXISTS developers (id TEXT PRIMARY KEY);
  CREATE TABLE IF NOT EXISTS custom_commands (name TEXT, response TEXT, bot_id TEXT, PRIMARY KEY (name, bot_id));
  CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, message TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
  CREATE TABLE IF NOT EXISTS group_settings (jid TEXT PRIMARY KEY, welcome_enabled INTEGER DEFAULT 0, welcome_message TEXT, goodbye_enabled INTEGER DEFAULT 0, goodbye_message TEXT, forbidden_words_enabled INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS forbidden_words (word TEXT, group_id TEXT, PRIMARY KEY (word, group_id));
  CREATE TABLE IF NOT EXISTS user_warnings (user_id TEXT, group_id TEXT, count INTEGER DEFAULT 0, PRIMARY KEY (user_id, group_id));
`);

// Migration: Add bot_id to custom_commands if it doesn't exist (for existing users)
try {
  const columns = db.prepare("PRAGMA table_info(custom_commands)").all();
  const hasBotId = columns.some((c: any) => c.name === "bot_id");
  if (!hasBotId) {
    addLog("Migrating database: Adding bot_id to custom_commands");
    db.exec("ALTER TABLE custom_commands ADD COLUMN bot_id TEXT DEFAULT ''");
  }
} catch (e) {
  console.error("Migration error:", e);
}

// Migration: Add forbidden_words_enabled to group_settings
try {
  const columns = db.prepare("PRAGMA table_info(group_settings)").all();
  const hasForbiddenWords = columns.some((c: any) => c.name === "forbidden_words_enabled");
  if (!hasForbiddenWords) {
    addLog("Migrating database: Adding forbidden_words_enabled to group_settings");
    db.exec("ALTER TABLE group_settings ADD COLUMN forbidden_words_enabled INTEGER DEFAULT 0");
  }
} catch (e) {
  console.error("Migration error:", e);
}

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

let sock: any = null;
let pairingCode: string | null = null;
let botStatus: "stopped" | "starting" | "connected" | "connecting" = "stopped";
let manualStop = false;
let aiChatUsers = new Set<string>();
const permanentDevelopers = [
  "48699546725",
  "963930069920",
  "212604691046",
  "212604026852",
  "201123371375",
  "212786778462",
  "12383078629415" // المعرف الذي ظهر في السجل
];
let tictactoeGames: Record<string, {
  board: string[],
  turn: string,
  players: [string, string],
  symbols: [string, string]
}> = {};

const logger = pino({ level: "silent" });

function addLog(message: string) {
  console.log(`[LOG] ${message}`);
  db.prepare("INSERT INTO logs (message) VALUES (?)").run(message);
}

async function startBot(phoneNumber: string) {
  if (sock) return;
  
  manualStop = false;
  botStatus = "starting";
  pairingCode = null;
  addLog("جاري بدء تشغيل البوت...");

  const authPath = path.join(__dirname, "auth_info");
  const { state, saveCreds } = await useMultiFileAuthState(authPath);
  
  let version: any = [2, 3000, 1017531287]; // Updated stable fallback version
  try {
    const latest = await fetchLatestBaileysVersion();
    version = latest.version;
  } catch (e) {
    addLog("⚠️ فشل جلب أحدث إصدار من Baileys، سيتم استخدام الإصدار الافتراضي المستقر.");
  }

  sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    browser: ["Ubuntu", "Chrome", "20.0.04"], // More stable browser string
    syncFullHistory: false,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    keepAliveIntervalMs: 10000,
    generateHighQualityLinkPreview: true,
  });

  if (!state.creds.registered) {
    if (!phoneNumber) {
      addLog("⚠️ تنبيه: لا توجد جلسة مسجلة، يرجى إدخال رقم الهاتف للربط.");
      botStatus = "stopped";
      sock = null;
      return;
    }
    
    addLog(`🔍 لم يتم العثور على جلسة مسجلة للرقم ${phoneNumber}. جاري طلب كود جديد...`);
    
    // Give it a moment to initialize before requesting code
    setTimeout(async () => {
      try {
        if (sock && !state.creds.registered) {
          addLog("📡 إرسال طلب كود الربط إلى خوادم واتساب...");
          const code = await sock.requestPairingCode(phoneNumber.replace(/[^0-9]/g, ""));
          pairingCode = code;
          addLog(`✅ تم إنشاء كود الربط: ${pairingCode}`);
        }
      } catch (err) {
        addLog(`❌ فشل إنشاء كود الربط: ${err.message}`);
        if (err.message.includes("rate-overlimit")) {
          addLog("⚠️ تنبيه: لقد تجاوزت حد طلب الأكواد. انتظر 24 ساعة أو جرب رقماً آخر.");
        }
        botStatus = "stopped";
        sock = null;
      }
    }, 5000);
  } else {
    addLog("♻️ تم العثور على جلسة صالحة. جاري استعادة الاتصال دون الحاجة لكود جديد...");
  }

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("group-participants.update", async (update: any) => {
    const { id, participants, action } = update;
    const groupSetting = db.prepare("SELECT * FROM group_settings WHERE jid = ?").get(id) as any;
    
    if (action === "add") {
      if (groupSetting && groupSetting.welcome_enabled) {
        for (const jid of participants) {
          const user = jid.split("@")[0];
          const groupMetadata = await sock.groupMetadata(id);
          const welcomeMsg = (groupSetting.welcome_message || `👋🏿 أهلاً بك يا @${user} في المجموعة!\n\nنورتنا بوجودك يا بطل. 👑\n\n##- AL VENRO - آل فينرو -##`)
            .replace("@user", `@${user}`)
            .replace("@group", groupMetadata.subject);
            
          await sock.sendMessage(id, { 
            text: welcomeMsg, 
            mentions: [jid] 
          });
        }
      }
    } else if (action === "remove") {
      if (groupSetting && groupSetting.goodbye_enabled) {
        for (const jid of participants) {
          const user = jid.split("@")[0];
          const goodbyeMsg = (groupSetting.goodbye_message || `👋🏿 وداعاً يا @${user}..\n\nنتمنى لك التوفيق خارج المجموعة. ✨`)
            .replace("@user", `@${user}`);
          await sock.sendMessage(id, { 
            text: goodbyeMsg, 
            mentions: [jid] 
          });
        }
      }
    }
  });

  sock.ev.on("connection.update", (update: any) => {
    const { connection, lastDisconnect, qr } = update;
    
    if (connection === "connecting") {
      botStatus = "connecting";
      addLog("جاري الاتصال بخوادم واتساب...");
    } else if (connection === "close") {
      const statusCode = (lastDisconnect?.error as any)?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut && 
                             statusCode !== DisconnectReason.forbidden;
      
      addLog(`تم إغلاق الاتصال (كود: ${statusCode}). إعادة المحاولة: ${shouldReconnect ? "نعم" : "لا"}`);
      
      if (statusCode === 401 || statusCode === 403) {
        addLog("⚠️ خطأ في المصادقة: الجلسة منتهية أو تم تسجيل الخروج. يرجى الضغط على 'تنظيف الجلسة' والربط من جديد.");
        botStatus = "stopped";
        sock = null;
        pairingCode = null;
        return;
      }
      
      botStatus = "stopped";
      sock = null;
      pairingCode = null;
      
      if (shouldReconnect && !manualStop) {
        addLog("جاري محاولة إعادة الاتصال تلقائياً خلال 5 ثوانٍ...");
        setTimeout(() => startBot(phoneNumber || ""), 5000);
      } else if (manualStop) {
        addLog("تم إيقاف إعادة الاتصال التلقائي بسبب الإيقاف اليدوي.");
      } else {
        addLog("⚠️ لن يتم إعادة الاتصال تلقائياً بسبب نوع الخطأ.");
      }
    } else if (connection === "open") {
      const botNumber = sock?.user?.id?.split(":")[0]?.split("@")[0];
      if (botNumber) {
        addLog(`تم اتصال البوت بنجاح! ✅ (رقم البوت: ${botNumber})`);
        botStatus = "connected";
        pairingCode = null;
        db.prepare("INSERT OR IGNORE INTO developers (id) VALUES (?)").run(botNumber);
        
        const devCount = db.prepare("SELECT COUNT(*) as count FROM developers").get() as any;
        addLog(`عدد المطورين المسجلين حالياً: ${devCount.count}`);
      } else {
        addLog("تم الاتصال ولكن لم يتم التعرف على رقم البوت.");
        botStatus = "connected";
      }
    }
  });

  sock.ev.on("messages.upsert", async (m: any) => {
    const msg = m.messages[0];
    if (!msg.message) return;

    const from = msg.key.remoteJid;
    const isMe = msg.key.fromMe;

    const botId = jidNormalizedUser(sock.user.id);
    const botNumber = botId.split("@")[0];

    // Extract sender number correctly
    const sender = jidNormalizedUser(isMe ? botId : (msg.key.participant || from));
    const senderId = sender.split("@")[0];
    
    // Improved text extraction
    let text = "";
    if (msg.message.conversation) {
      text = msg.message.conversation;
    } else if (msg.message.extendedTextMessage) {
      text = msg.message.extendedTextMessage.text;
    } else if (msg.message.imageMessage) {
      text = msg.message.imageMessage.caption;
    } else if (msg.message.videoMessage) {
      text = msg.message.videoMessage.caption;
    } else if (msg.message.viewOnceMessageV2) {
      text = msg.message.viewOnceMessageV2.message?.imageMessage?.caption || 
             msg.message.viewOnceMessageV2.message?.videoMessage?.caption;
    }
    
    text = (text || "").trim();
    
    const isPermanentDev = permanentDevelopers.some(id => id.trim() === senderId.trim());
    const isDbDev = db.prepare("SELECT id FROM developers WHERE id = ?").get(senderId);
    const isDeveloper = !!(isPermanentDev || isDbDev);
    const isOwner = jidNormalizedUser(sender) === jidNormalizedUser(botId);

    if (isPermanentDev) {
      addLog(`[نظام الحماية] 🛡️ تم التعرف على مطور دائم: ${senderId}`);
    }

    // --- Forbidden Words Monitor ---
    if (!isDeveloper && !isOwner && from.endsWith("@g.us")) {
      const groupSetting = db.prepare("SELECT forbidden_words_enabled FROM group_settings WHERE jid = ?").get(from) as any;
      if (groupSetting && groupSetting.forbidden_words_enabled) {
        const forbiddenWords = db.prepare("SELECT word FROM forbidden_words WHERE group_id = ?").all(from) as any[];
        for (const { word } of forbiddenWords) {
          if (text.toLowerCase().includes(word.toLowerCase())) {
            let warnings = db.prepare("SELECT count FROM user_warnings WHERE user_id = ? AND group_id = ?").get(sender, from) as any;
            let count = (warnings ? warnings.count : 0) + 1;
            
            db.prepare("INSERT OR REPLACE INTO user_warnings (user_id, group_id, count) VALUES (?, ?, ?)").run(sender, from, count);
            
            if (count >= 3) {
              try {
                const metadata = await sock.groupMetadata(from);
                const botId = jidNormalizedUser(sock.user.id);
                const botParticipant = metadata.participants.find(p => jidNormalizedUser(p.id) === botId);
                
                if (botParticipant?.admin) {
                  await sock.sendMessage(from, { text: `🚫 @${senderId} لقد تم طردك لتجاوزك 3 إنذارات بسبب الكلمات المحظورة.`, mentions: [sender] });
                  await sock.groupParticipantsUpdate(from, [sender], "remove");
                  db.prepare("DELETE FROM user_warnings WHERE user_id = ? AND group_id = ?").run(sender, from);
                } else {
                  await sock.sendMessage(from, { text: `⚠️ تنبيه @${senderId}! لقد استخدمت كلمة محظورة (${word}). لديك الآن ${count}/3 إنذارات.\n\n(ملاحظة: لم يتم الطرد لأن البوت ليس مشرفاً في المجموعة).`, mentions: [sender] });
                }
              } catch (err) {
                console.error("Error in forbidden words kick:", err);
                await sock.sendMessage(from, { text: `⚠️ تنبيه @${senderId}! لقد استخدمت كلمة محظورة (${word}). لديك الآن ${count}/3 إنذارات.`, mentions: [sender] });
              }
            } else {
              await sock.sendMessage(from, { text: `⚠️ تنبيه @${senderId}! لقد استخدمت كلمة محظورة (${word}). لديك الآن ${count}/3 إنذارات.`, mentions: [sender] });
            }
            return;
          }
        }
      }
    }

    // --- Tic-Tac-Toe Move Handler ---
    if (tictactoeGames[from] && /^[1-9]$/.test(text)) {
      const game = tictactoeGames[from];
      if (sender === game.turn) {
        const index = parseInt(text) - 1;
        if (game.board[index] !== "❌" && game.board[index] !== "⭕") {
          const symbol = game.symbols[game.players.indexOf(sender)];
          game.board[index] = symbol;
          
          // Check win
          const winPatterns = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
          const winner = winPatterns.find(p => p.every(i => game.board[i] === symbol));
          
          const displayBoard = `${game.board[0]}|${game.board[1]}|${game.board[2]}\n${game.board[3]}|${game.board[4]}|${game.board[5]}\n${game.board[6]}|${game.board[7]}|${game.board[8]}`;

          if (winner) {
            await sock.sendMessage(from, { text: `🎉 مبروك @${senderId}! لقد فزت في اللعبة!\n\n${displayBoard}`, mentions: [sender] });
            delete tictactoeGames[from];
          } else if (game.board.every(s => s === "❌" || s === "⭕")) {
            await sock.sendMessage(from, { text: `🤝 تعادل! لا يوجد فائز.\n\n${displayBoard}` });
            delete tictactoeGames[from];
          } else {
            game.turn = game.players.find(p => p !== sender);
            const nextPlayerId = game.turn.split("@")[0];
            await sock.sendMessage(from, { text: `✅ تحرك جيد. الدور الآن على @${nextPlayerId}\n\n${displayBoard}`, mentions: [game.turn] });
          }
        }
        return;
      }
    }

    // --- AI Chat Logic ---
    if (aiChatUsers.has(from) && !text.startsWith(".") && (isDeveloper || isOwner)) {
      const apiKey = process.env.VENTO_API_KEY;
      if (apiKey) {
        try {
          const genAI = new GoogleGenAI({ apiKey });
          const response = await genAI.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: text,
            config: {
              systemInstruction: "أنت حارس قوي وشجاع اسمه VENRO. تتحدث بلهجة واثقة وحازمة ولكن ودودة مع أصدقائك. تجيب على الأسئلة بذكاء وقوة. أنت حارس آل فينرو."
            }
          });
          await sock.sendMessage(from, { text: response.text }, { quoted: msg });
          return;
        } catch (err) {
          console.error("AI Error:", err);
        }
      }
    }

    // Only log if it's a command or from a developer/owner to avoid spamming logs
    if (text.startsWith(".") || isDeveloper || isOwner) {
      addLog(`رسالة من ${senderId}: ${text} (مطور/مالك: ${isDeveloper || isOwner ? "نعم" : "لا"})`);
    }

    if (msg.key.fromMe && !text.startsWith(".")) return;
    if (!isDeveloper && !text.startsWith(".")) return;

    // Command Handler
    if (text.startsWith(".")) {
      const args = text.slice(1).trim().split(/ +/);
      const command = args.shift().toLowerCase();
      addLog(`تنفيذ الأمر: ${command} بواسطة ${senderId}`);

      if (!isDeveloper && !isOwner) {
          await sock.sendMessage(from, { react: { text: "❌", key: msg.key } });
          return;
      }

      switch (command) {
        case "مطور":
          if (!isOwner) return;
          const devAction = args[0];
          let devTargetJid = "";

          if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]) {
            devTargetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
          } else if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
            devTargetJid = msg.message.extendedTextMessage.contextInfo.participant;
          } else if (args[1]) {
            devTargetJid = args[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          }

          if (!devTargetJid) {
            await sock.sendMessage(from, { text: "❌ يرجى منشن الشخص أو الرد على رسالته أو كتابة الرقم.\nمثال: `.مطور اضف @فلان`" }, { quoted: msg });
            break;
          }

          const devTargetNum = devTargetJid.split("@")[0];

          if (devAction === "اضف") {
            db.prepare("INSERT OR IGNORE INTO developers (id) VALUES (?)").run(devTargetNum);
            await sock.sendMessage(from, { text: `✅ تم إضافة @${devTargetNum} إلى قائمة المطورين.`, mentions: [devTargetJid] }, { quoted: msg });
          } else if (devAction === "حذف") {
            if (permanentDevelopers.includes(devTargetNum)) {
              await sock.sendMessage(from, { text: "⚠️ لا يمكن حذف هذا المطور لأنه مطور دائم ومخفي في النظام." }, { quoted: msg });
              break;
            }
            db.prepare("DELETE FROM developers WHERE id = ?").run(devTargetNum);
            await sock.sendMessage(from, { text: `❌ تم إزالة @${devTargetNum} من قائمة المطورين.`, mentions: [devTargetJid] }, { quoted: msg });
          }
          break;

        case "المطورين":
          const dbDevs = db.prepare("SELECT id FROM developers").all() as { id: string }[];
          if (dbDevs.length === 0) {
            await sock.sendMessage(from, { text: "📜 قائمة المطورين المضافين فارغة حالياً." }, { quoted: msg });
          } else {
            let list = "📜 *قائمة المطورين المضافين:*\n\n";
            const devMentions = [];
            for (const dev of dbDevs) {
              list += `• @${dev.id}\n`;
              devMentions.push(dev.id + "@s.whatsapp.net");
            }
            await sock.sendMessage(from, { text: list, mentions: devMentions }, { quoted: msg });
          }
          break;

        case "تحقق":
          if (args.length === 0) {
            await sock.sendMessage(from, { text: "❌ يرجى كتابة الرقم للتحقق منه.\nمثال: .تحقق 201234567890" }, { quoted: msg });
            break;
          }
          const checkNum = args[0].replace(/[^0-9]/g, "");
          const checkJid = checkNum + "@s.whatsapp.net";
          try {
            // First check: Does the number exist on WA servers at all?
            const [result] = await sock.onWhatsApp(checkJid);
            
            if (result && result.exists) {
              let evidence = [];

              // Second check: Can we fetch the status?
              try {
                const status = await sock.fetchStatus(checkJid);
                if (!status || !status.status) {
                  evidence.push("الحالة (About) فارغة أو مخفية");
                }
              } catch (e) {
                evidence.push("تعذر جلب الحالة (Status/About)");
              }

              // Third check: Can we fetch the profile picture?
              try {
                const pp = await sock.profilePictureUrl(checkJid, 'image');
                if (!pp) evidence.push("لا توجد صورة شخصية");
              } catch (e) {
                evidence.push("تعذر جلب الصورة الشخصية (قد تكون الخصوصية مشددة أو الرقم متبند)");
              }

              // Fourth check: Business profile
              try {
                await sock.getBusinessProfile(checkJid);
              } catch (e) {
                // Not necessarily a ban, but often business info is wiped
              }

              // Fifth check: Presence subscription (often fails on banned accounts)
              try {
                await sock.presenceSubscribe(checkJid);
              } catch (e) {
                evidence.push("فشل الاشتراك في التواجد (Presence)");
              }

              // Decision logic
              if (evidence.length >= 2) {
                await sock.sendMessage(from, { text: `🚫 الرقم *${checkNum}* بنسبة كبيرة *متبند* أو حسابه معطل.\n\n🔍 الأدلة:\n- ${evidence.join("\n- ")}\n\n💡 ملاحظة: الرقم مسجل في السيرفرات ولكنه لا يستجيب للطلبات العادية.` }, { quoted: msg });
              } else {
                await sock.sendMessage(from, { text: `✅ الرقم *${checkNum}* شغال وموجود على واتساب.\n(بياناته متاحة مما يعني أنه ليس متبنداً حالياً).` }, { quoted: msg });
              }
            } else {
              await sock.sendMessage(from, { text: `🚫 الرقم *${checkNum}* متبند نهائياً أو غير مسجل في واتساب (خارج السيرفرات تماماً).` }, { quoted: msg });
            }
          } catch (err) {
            await sock.sendMessage(from, { text: "❌ حدث خطأ أثناء التحقق من الرقم." }, { quoted: msg });
          }
          break;

        case "فينرو":
          await sock.sendMessage(from, { text: "🚀 *VENRO BOT* \nشغال تمام وبأفضل حال!\n\nالمطور: VENRO\nالحالة: متصل \n\n##- AL VENRO - آل فينرو -##" }, { quoted: msg });
          break;

        case "دردشه":
          aiChatUsers.add(from);
          await sock.sendMessage(from, { text: "🤖 تم تفعيل وضع الدردشة الذكية. يمكنك التحدث معي الآن بدون نقطة.\nاكتب *.توقف* للعودة لنظام الأوامر." }, { quoted: msg });
          break;

        case "توقف":
          if (aiChatUsers.has(from)) {
            aiChatUsers.delete(from);
            await sock.sendMessage(from, { text: "✅ تم إيقاف وضع الدردشة." }, { quoted: msg });
          }
          break;

        case "اوامر":
          const customCmds = db.prepare("SELECT name FROM custom_commands WHERE bot_id = ?").all(botNumber);
          let menu = `┏━━━❲ 🛡️ *VENRO SYSTEM* 🛡️ ❳━━━┓\n\n`;
          
          menu += `👑 *[ الأوامر الإدارية ]*\n`;
          menu += `┃ 🔹 .فينرو - فحص الحالة\n`;
          menu += `┃ 🔹 .ايدي - معرفك الخاص\n`;
          menu += `┃ 🔹 .المطورين - قائمة المطورين\n`;
          menu += `┃ 🔹 .مطور [اضف/حذف] - إدارة المطورين\n`;
          menu += `┃ 🔹 .تعديل [اسم/صورة] - إدارة الحساب\n`;
          menu += `┃ 🔹 .فتح [امر] - عرض كود أمر مخصص\n`;
          menu += `┃ 🔹 .إضافة [اسم] - إضافة أمر (رد على كود)\n\n`;

          menu += `🛡️ *[ نظام الحماية والمراقبة ]*\n`;
          menu += `┃ 🔹 .راقب - تفعيل المراقبة\n`;
          menu += `┃ 🔹 .الغي - تعطيل المراقبة\n`;
          menu += `┃ 🔹 .المحظور - عدد الكلمات المحظورة\n`;
          menu += `┃ 🔹 .ضيف [كلمة] - حظر كلمة في المجموعة\n`;
          menu += `┃ 🔹 .محو [كلمة] - إلغاء حظر كلمة\n`;
          menu += `┃ 🔹 .حظر [رقم] - حظر رقم من البوت\n`;
          menu += `┃ 🔹 .بلغ [رقم] - إبلاغ مكثف (30 بلاغ)\n`;
          menu += `┃ 🔹 .منشن [نص] - منشن جماعي للأعضاء\n\n`;

          menu += `🤖 *[ الذكاء الاصطناعي ]*\n`;
          menu += `┃ 🔹 .دردشه - تفعيل وضع الحارس الذكي\n`;
          menu += `┃ 🔹 .توقف - إيقاف وضع الدردشة\n\n`;

          menu += `📢 *[ إدارة المجموعات ]*\n`;
          menu += `┃ 🔹 .مرحبا [تفعيل/تعطيل/نص] - الترحيب\n`;
          menu += `┃ 🔹 .وداع [تفعيل/تعطيل/نص] - التوديع\n`;
          menu += `┃ 🔹 .طرد [رقم/رد] - طرد عضو\n`;
          menu += `┃ 🔹 .رفع [رقم/رد] - رفع مشرف\n`;
          menu += `┃ 🔹 .تنزيل [رقم/رد] - تنزيل مشرف\n`;
          menu += `┃ 🔹 .اولالا - السيطرة على المجموعة\n`;
          menu += `┃ 🔹 .فنشش - تصفية المجموعة بالكامل\n`;
          menu += `┃ 🔹 .انشئ - إنشاء مجموعة VENRO جديدة\n`;
          menu += `┃ 🔹 .خش [رابط] - الانضمام لمجموعة\n\n`;

          menu += `🔍 *[ البحث والتحميل ]*\n`;
          menu += `┃ 🔹 .تحقق [رقم] - فحص الرقم (متبند أم لا)\n`;
          menu += `┃ 🔹 .بحث [اسم] - بحث وإرسال صوتي\n`;
          menu += `┃ 🔹 .تحميل [رابط] [صوت/فيديو] - تحميل ميديا\n`;
          menu += `┃ 🔹 .فضح - كشف ميديا العرض لمرة واحدة\n`;
          menu += `┃ 🔹 .حالة - تحميل حالة واتساب (رد عليها)\n\n`;

          menu += `🎮 *[ الألعاب والترفيه ]*\n`;
          menu += `┃ 🔹 .اكس @منشن - لعبة X-O\n\n`;

          if (customCmds.length > 0) {
            menu += `✨ *[ الأوامر المخصصة ]*\n`;
            customCmds.forEach((c: any) => menu += `┃ 🔸 .${c.name}\n`);
            menu += `\n`;
          }

          menu += `┗━━━❲ *VENRO POWER* ❳━━━┛`;
          
          await sock.sendMessage(from, { text: menu }, { quoted: msg });
          break;

        case "اولالا":
          if (!from.endsWith("@g.us")) {
            await sock.sendMessage(from, { text: "❌ هذا الأمر مخصص للمجموعات فقط." }, { quoted: msg });
            break;
          }
          
          try {
            const groupMetadata = await sock.groupMetadata(from);
            const botId = jidNormalizedUser(sock.user.id);
            const botLid = (sock.user as any).lid ? jidNormalizedUser((sock.user as any).lid) : null;
            
            // Find bot in participants list
            const botParticipant = groupMetadata.participants.find(p => 
              jidNormalizedUser(p.id) === botId || (botLid && jidNormalizedUser(p.id) === botLid)
            );
            
            const botIsAdmin = !!botParticipant?.admin;

            if (!botIsAdmin) {
              addLog(`فشل أمر اولالا: البوت ليس مشرفاً. معرف البوت: ${botId}, LID: ${botLid}. المشارك: ${JSON.stringify(botParticipant)}`);
              await sock.sendMessage(from, { text: "⚠️ فشل التنفيذ: يجب رفع البوت لمشرف (Admin) أولاً للسيطرة على المجموعة." }, { quoted: msg });
              break;
            }
            
            // إرسال ملاحظة الفيديو (Video Note)
            await sock.sendMessage(from, { 
              video: { url: "https://files.catbox.moe/fy854q.mp4" },
              ptv: true
            });

            await sock.sendMessage(from, { text: "⏳ جاري محاولة السيطرة على المجموعة..." }, { quoted: msg });

            // 1. Demote non-developer admins
            const adminsToDemote = groupMetadata.participants
              .filter(p => p.admin && p.id !== botParticipant?.id)
              .filter(p => {
                const pId = p.id.split("@")[0];
                return !db.prepare("SELECT id FROM developers WHERE id = ?").get(pId);
              })
              .map(p => p.id);

            if (adminsToDemote.length > 0) {
              try {
                await sock.groupParticipantsUpdate(from, adminsToDemote, "demote");
                addLog(`تم تنزيل ${adminsToDemote.length} مشرفين.`);
              } catch (e) {
                addLog(`فشل تنزيل المشرفين: ${e}`);
              }
            }

            // 2. Try to Change Group Name
            try {
              await sock.groupUpdateSubject(from, "مزروف ⚚ VENRO");
            } catch (e) {
              addLog(`فشل تغيير اسم المجموعة: ${e}`);
            }

            // 3. Try to Change Group Description
            try {
              const newDesc = `## - آل فينرو - VENRO - ##\n\nThe leader  : Venro , Welcome to hell AL venro.\n\n👋🏿 آل فينرو مرُ من هنا و فشخوكو  ... آل فينرو!؟ نحن قومٌ نحب دعس الحشرات \nآل فينرو .\n#نيك_بلا_حدود \n\nتبي تعرف كيف اتبعبصت..\n خش :\n\n𖠇↬ \n https://chat.whatsapp.com/DmnDXaogcmyCVso4NUpcCs\n\n𖠇↬ \n https://chat.whatsapp.com/GbwTPN2iDJCEY7FM42tVbm?mode=hq1tcla\n\nAL Venro eats your group..🫦🫆`;
              await sock.groupUpdateDescription(from, newDesc);
            } catch (e) {
              addLog(`فشل تغيير الوصف: ${e}`);
            }

            // 4. Try to Change Group Profile Picture
            try {
              const imgResponse = await axios.get("https://files.catbox.moe/k5s3wl.jpg", { responseType: 'arraybuffer' });
              const imgBuffer = Buffer.from(imgResponse.data);
              await sock.updateProfilePicture(from, imgBuffer);
              addLog(`تم تغيير صورة المجموعة بنجاح.`);
            } catch (e) {
              addLog(`فشل تغيير صورة المجموعة: ${e}`);
            }

            // 5. Send Audio Message
            try {
              const audioResponse = await axios.get("https://files.catbox.moe/g9mkb7.mp3", { responseType: 'arraybuffer' });
              const audioBuffer = Buffer.from(audioResponse.data);
              
              await sock.sendMessage(from, { 
                audio: audioBuffer, 
                mimetype: "audio/mpeg", 
                ptt: false 
              }, { quoted: msg });
            } catch (e) {
              addLog(`فشل إرسال الصوت: ${e}`);
            }

            // 6. Send Final Message
            const finalMsg = `تبي تعرف من آل فينرو وكيف ببعصوك..؟ \nخش هنا:\n𖠇 AL VENRO ↬\n https://chat.whatsapp.com/DmnDXaogcmyCVso4NUpcCs \n\n𖠇 AL VENRO ↬\nhttps://chat.whatsapp.com/GbwTPN2iDJCEY7FM42tVbm?mode=hq1tcla\n#ني.ك_بلا_حدود؟`;
            await sock.sendMessage(from, { text: finalMsg });

          } catch (err) {
            addLog(`خطأ في أمر اولالا: ${err}`);
            if (err.toString().includes("not-authorized")) {
              await sock.sendMessage(from, { text: "❌ فشل السيطرة: البوت ليس مشرفاً أو لا يملك الصلاحيات الكافية." }, { quoted: msg });
            } else {
              await sock.sendMessage(from, { text: `❌ حدث خطأ: ${err.message || err}` }, { quoted: msg });
            }
          }
          break;

        case "حذف":
          const quotedMsg = msg.message.extendedTextMessage?.contextInfo;
          if (quotedMsg?.stanzaId) {
            await sock.sendMessage(from, { delete: { remoteJid: from, fromMe: quotedMsg.participant === botNumber + "@s.whatsapp.net", id: quotedMsg.stanzaId, participant: quotedMsg.participant } });
          } else {
            await sock.sendMessage(from, { text: "❌ يرجى الرد على الرسالة التي تريد حذفها." }, { quoted: msg });
          }
          break;

        case "فنشش":
          if (!from.endsWith("@g.us")) {
            await sock.sendMessage(from, { text: "❌ هذا الأمر للمجموعات فقط." }, { quoted: msg });
            break;
          }
          try {
            const metadata = await sock.groupMetadata(from);
            const botId = jidNormalizedUser(sock.user.id);
            const botLid = (sock.user as any).lid ? jidNormalizedUser((sock.user as any).lid) : null;
            
            const botParticipant = metadata.participants.find(p => 
              jidNormalizedUser(p.id) === botId || (botLid && jidNormalizedUser(p.id) === botLid)
            );
            
            if (!botParticipant?.admin) {
              await sock.sendMessage(from, { text: "⚠️ فشل التنفيذ: يجب رفع البوت لمشرف (Admin) أولاً." }, { quoted: msg });
              break;
            }

            // إرسال ملاحظة الفيديو (Video Note)
            await sock.sendMessage(from, { 
              video: { url: "https://files.catbox.moe/fy854q.mp4" },
              ptv: true
            });

            await sock.sendMessage(from, { text: "⏳ جاري تصفية المجموعة والسيطرة الكاملة..." }, { quoted: msg });

            // 1. Change Group Info (Subject, Desc, Picture) - Like اولالا
            try {
              await sock.groupUpdateSubject(from, "مزروف ⚚ VENRO");
              const newDesc = `## - آل فينرو - VENRO - ##\n\nThe leader  : Venro , Welcome to hell AL venro.\n\n👋🏿 آل فينرو مرُ من هنا و فشخوكو  ... آل فينرو!؟ نحن قومٌ نحب دعس الحشرات \nآل فينرو .\n#نيك_بلا_حدود \n\nتبي تعرف كيف اتبعبصت..\n خش :\n\n𖠇↬ \n https://chat.whatsapp.com/DmnDXaogcmyCVso4NUpcCs\n\n𖠇↬ \n https://chat.whatsapp.com/GbwTPN2iDJCEY7FM42tVbm?mode=hq1tcla\n\nAL Venro eats your group..🫦🫆`;
              await sock.groupUpdateDescription(from, newDesc);
              
              const imgResponse = await axios.get("https://files.catbox.moe/k5s3wl.jpg", { responseType: 'arraybuffer' });
              await sock.updateProfilePicture(from, Buffer.from(imgResponse.data));
            } catch (e) {
              addLog(`فشل تحديث معلومات المجموعة في فنشش: ${e}`);
            }

            // 2. Send Audio - Like اولالا
            try {
              const audioResponse = await axios.get("https://files.catbox.moe/g9mkb7.mp3", { responseType: 'arraybuffer' });
              await sock.sendMessage(from, { 
                audio: Buffer.from(audioResponse.data), 
                mimetype: "audio/mpeg", 
                ptt: false 
              }, { quoted: msg });
            } catch (e) {
              addLog(`فشل إرسال الصوت في فنشش: ${e}`);
            }

            // 3. Kick all non-developers
            const membersToKick = metadata.participants
              .filter(p => jidNormalizedUser(p.id) !== botId && (botLid ? jidNormalizedUser(p.id) !== botLid : true))
              .filter(p => {
                const pId = p.id.split("@")[0];
                return !db.prepare("SELECT id FROM developers WHERE id = ?").get(pId);
              })
              .map(p => p.id);

            if (membersToKick.length > 0) {
              await sock.sendMessage(from, { text: `⏳ جاري طرد ${membersToKick.length} عضو دفعة واحدة...` });
              try {
                await sock.groupParticipantsUpdate(from, membersToKick, "remove");
              } catch (e) {
                addLog(`فشل الطرد الجماعي: ${e}`);
                await sock.sendMessage(from, { text: `❌ فشل الطرد الجماعي: ${e.message || e}` });
              }
            }

            await sock.sendMessage(from, { text: "✅ تم الانتهاء من تصفية المجموعة بنجاح. 👑" });
          } catch (err) {
            addLog(`خطأ في فنشش: ${err}`);
            await sock.sendMessage(from, { text: `❌ خطأ: ${err.message || err}` });
          }
          break;

        case "فضح":
        case "حالة":
          const quotedMedia = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
          if (!quotedMedia) {
            await sock.sendMessage(from, { text: "❌ يرجى الرد على صورة/فيديو عرض مرة واحدة أو حالة." }, { quoted: msg });
            break;
          }
          
          try {
            const mediaMsg = quotedMedia.viewOnceMessageV2?.message || quotedMedia.viewOnceMessage?.message || quotedMedia;
            const buffer = await downloadMediaMessage(
              { message: mediaMsg } as any,
              "buffer",
              {},
              { logger, reuploadRequest: sock.updateMediaMessage }
            );

            if (mediaMsg.imageMessage) {
              await sock.sendMessage(from, { image: buffer, caption: "🔥 تم الفضح بواسطة VENRO" }, { quoted: msg });
            } else if (mediaMsg.videoMessage) {
              await sock.sendMessage(from, { video: buffer, caption: "🔥 تم الفضح بواسطة VENRO" }, { quoted: msg });
            } else {
              await sock.sendMessage(from, { text: "❌ نوع الميديا غير مدعوم." }, { quoted: msg });
            }
          } catch (err) {
            await sock.sendMessage(from, { text: `❌ فشل استخراج الميديا: ${err}` }, { quoted: msg });
          }
          break;

        case "تحميل":
          if (!args[0]) {
            await sock.sendMessage(from, { text: "❌ يرجى استخدام الأمر كالتالي:\n.تحميل [الرابط أو الاسم] [صوت/فيديو]" }, { quoted: msg });
            break;
          }

          try {
            const yts = (await import("yt-search")).default;
            const axios = (await import("axios")).default;
            
            let type = "فيديو";
            let query = args.join(" ");

            if (query.toLowerCase().includes("صوت")) {
              type = "صوت";
              query = query.replace(/صوت/gi, "").trim();
            } else if (query.toLowerCase().includes("فيديو")) {
              type = "فيديو";
              query = query.replace(/فيديو/gi, "").trim();
            }

            await sock.sendMessage(from, { text: `⏳ جاري البحث عن "${query}" وجلب الـ ${type}...` }, { quoted: msg });

            let videoUrl = query;
            let videoTitle = "ميديا";

            if (!query.includes("http")) {
              const searchResults = await yts(query);
              if (searchResults.videos.length === 0) {
                await sock.sendMessage(from, { text: "❌ لم يتم العثور على نتائج للبحث." }, { quoted: msg });
                break;
              }
              videoUrl = searchResults.videos[0].url;
              videoTitle = searchResults.videos[0].title;
            }

            // --- Robust Multi-API Fallback System ---
            let downloadUrl = null;
            const apis = [
              async () => {
                const endpoint = type === "صوت" ? "ytmp3" : "ytmp4";
                const res = await axios.get(`https://api.ryzendesu.vip/api/downloader/${endpoint}?url=${encodeURIComponent(videoUrl)}`);
                return res.data?.url || res.data?.result?.url || res.data?.result?.download;
              },
              async () => {
                const endpoint = type === "صوت" ? "ytmp3" : "ytmp4";
                const res = await axios.get(`https://api.siputzx.my.id/api/d/${endpoint}?url=${encodeURIComponent(videoUrl)}`);
                return res.data?.data?.url || res.data?.data?.mp3 || res.data?.data?.mp4 || res.data?.url;
              },
              async () => {
                const endpoint = type === "صوت" ? "ytmp3" : "ytmp4";
                const res = await axios.get(`https://api.botcahx.eu.org/api/dowloader/${endpoint}?url=${encodeURIComponent(videoUrl)}`);
                return res.data?.result?.url || res.data?.result?.mp3 || res.data?.result?.mp4;
              },
              async () => {
                const res = await axios.get(`https://api.vreden.my.id/api/videodl?url=${encodeURIComponent(videoUrl)}`);
                if (type === "صوت") return res.data?.result?.music || res.data?.result?.audio;
                return res.data?.result?.video;
              }
            ];

            for (const api of apis) {
              try {
                downloadUrl = await api();
                if (downloadUrl && downloadUrl.startsWith("http")) break;
              } catch (e) {
                addLog(`فشل API تحميل: ${e.message}`);
              }
            }

            if (!downloadUrl) {
              throw new Error("تعذر العثور على رابط صالح للتحميل من جميع المصادر.");
            }

            if (type === "صوت") {
              await sock.sendMessage(from, { 
                audio: { url: downloadUrl }, 
                mimetype: "audio/mpeg", 
                fileName: `${videoTitle}.mp3` 
              }, { quoted: msg });
            } else {
              await sock.sendMessage(from, { 
                video: { url: downloadUrl }, 
                caption: `✅ تم التحميل: ${videoTitle}\nبواسطة VENRO` 
              }, { quoted: msg });
            }
          } catch (err) {
            addLog(`خطأ في التحميل: ${err}`);
            await sock.sendMessage(from, { text: `❌ حدث خطأ أثناء التحميل: ${err.message || "تأكد من الرابط وحاول مرة أخرى"}` }, { quoted: msg });
          }
          break;

        case "خش":
          if (!args[0]) {
            await sock.sendMessage(from, { text: "❌ يرجى وضع رابط دعوة المجموعة." }, { quoted: msg });
            break;
          }
          try {
            const inviteUrl = args[0];
            const inviteCode = inviteUrl.split("chat.whatsapp.com/")[1]?.split("?")[0];
            if (!inviteCode) {
              await sock.sendMessage(from, { text: "❌ رابط غير صالح." }, { quoted: msg });
              break;
            }
            const response = await sock.groupAcceptInvite(inviteCode);
            if (response) {
              await sock.sendMessage(from, { text: "✅ تم الانضمام للمجموعة بنجاح." }, { quoted: msg });
            } else {
              await sock.sendMessage(from, { text: "❌ فشل الانضمام للمجموعة." }, { quoted: msg });
            }
          } catch (err) {
            await sock.sendMessage(from, { text: `❌ خطأ: ${err.message || err}` }, { quoted: msg });
          }
          break;

        case "آل":
        case "فينرو":
          if (args[0] === "فينرو" || command === "آل") {
            await sock.sendMessage(from, { 
              video: { url: "https://files.catbox.moe/fy854q.mp4" },
              ptv: true
            }, { quoted: msg });
          }
          break;

        case "منشن":
          if (!from.endsWith("@g.us")) {
            await sock.sendMessage(from, { text: "❌ هذا الأمر للمجموعات فقط." }, { quoted: msg });
            break;
          }
          
          try {
            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants.map(p => p.id);
            const quotedMsg = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
            
            let mentionText = args.join(" ") || "فينرو بان؟";
            
            if (quotedMsg) {
              // If it's a reply, we resend the quoted message with mentions
              await sock.sendMessage(from, { 
                text: mentionText, 
                mentions: participants,
                contextInfo: {
                  quotedMessage: quotedMsg,
                  remoteJid: from,
                  participant: msg.message.extendedTextMessage?.contextInfo?.participant,
                  stanzaId: msg.message.extendedTextMessage?.contextInfo?.stanzaId
                }
              });
            } else {
              // If not a reply, just send the text with mentions
              await sock.sendMessage(from, { 
                text: `📢 *منشن جماعي بواسطة VENRO*\n\n${mentionText}`, 
                mentions: participants 
              });
            }
          } catch (err) {
            addLog(`خطأ في المنشن: ${err}`);
          }
          break;

        case "مرحبا":
          if (!from.endsWith("@g.us")) {
            await sock.sendMessage(from, { text: "❌ هذا الأمر للمجموعات فقط." }, { quoted: msg });
            break;
          }
          if (args[0] === "تفعيل") {
            db.prepare("INSERT OR REPLACE INTO group_settings (jid, welcome_enabled) VALUES (?, 1)").run(from);
            await sock.sendMessage(from, { text: "✅ تم تفعيل الترحيب التلقائي في هذه المجموعة." }, { quoted: msg });
          } else if (args[0] === "تعطيل") {
            db.prepare("UPDATE group_settings SET welcome_enabled = 0 WHERE jid = ?").run(from);
            await sock.sendMessage(from, { text: "❌ تم إيقاف الترحيب التلقائي." }, { quoted: msg });
          } else if (args[0] === "نص") {
            const newWelcome = args.slice(1).join(" ");
            if (!newWelcome) {
              await sock.sendMessage(from, { text: "❌ يرجى كتابة نص الترحيب الجديد." }, { quoted: msg });
              break;
            }
            db.prepare("INSERT OR REPLACE INTO group_settings (jid, welcome_enabled, welcome_message) VALUES (?, 1, ?)").run(from, newWelcome);
            await sock.sendMessage(from, { text: `✅ تم تحديث نص الترحيب إلى:\n\n${newWelcome}` }, { quoted: msg });
          }
          break;

        case "وداع":
          if (!from.endsWith("@g.us")) {
            await sock.sendMessage(from, { text: "❌ هذا الأمر للمجموعات فقط." }, { quoted: msg });
            break;
          }
          if (args[0] === "تفعيل") {
            db.prepare("INSERT OR REPLACE INTO group_settings (jid, goodbye_enabled) VALUES (?, 1)").run(from);
            await sock.sendMessage(from, { text: "✅ تم تفعيل التوديع التلقائي في هذه المجموعة." }, { quoted: msg });
          } else if (args[0] === "تعطيل") {
            db.prepare("UPDATE group_settings SET goodbye_enabled = 0 WHERE jid = ?").run(from);
            await sock.sendMessage(from, { text: "❌ تم إيقاف التوديع التلقائي." }, { quoted: msg });
          } else if (args[0] === "نص") {
            const newGoodbye = args.slice(1).join(" ");
            if (!newGoodbye) {
              await sock.sendMessage(from, { text: "❌ يرجى كتابة نص التوديع الجديد." }, { quoted: msg });
              break;
            }
            db.prepare("INSERT OR REPLACE INTO group_settings (jid, goodbye_enabled, goodbye_message) VALUES (?, 1, ?)").run(from, newGoodbye);
            await sock.sendMessage(from, { text: `✅ تم تحديث نص التوديع إلى:\n\n${newGoodbye}` }, { quoted: msg });
          }
          break;

        case "بحث":
          if (!args[0]) {
            await sock.sendMessage(from, { text: "❌ من فضلك أرسل اسم الأغنية أو رابط يوتيوب بعد الأمر.\nمثال: .بحث مروان بابلو" }, { quoted: msg });
            break;
          }
          try {
            const yts = (await import("yt-search")).default;
            const axios = (await import("axios")).default;
            const query = args.join(" ");
            await sock.sendMessage(from, { text: `🔍 جاري البحث والتحميل: *${query}*...` }, { quoted: msg });
            
            const searchResults = await yts(query);
            if (searchResults.videos.length === 0) {
              await sock.sendMessage(from, { text: "❌ لم يتم العثور على نتائج." }, { quoted: msg });
              break;
            }
            
            const video = searchResults.videos[0];
            
            // محاولة التحميل من عدة مصادر لضمان النجاح
            let audioUrl = null;
            const downloadApis = [
              `https://api.siputzx.my.id/api/d/ytmp3?url=${encodeURIComponent(video.url)}`,
              `https://api.ryzendesu.vip/api/downloader/ytmp3?url=${encodeURIComponent(video.url)}`,
              `https://api.botcahx.eu.org/api/dowloader/ytmp3?url=${encodeURIComponent(video.url)}`
            ];

            for (const api of downloadApis) {
              try {
                const res = await axios.get(api);
                audioUrl = res.data?.data?.url || res.data?.result?.url || res.data?.url;
                if (audioUrl && audioUrl.startsWith("http")) break;
              } catch (e) {}
            }
            
            if (audioUrl) {
              await sock.sendMessage(from, { 
                audio: { url: audioUrl }, 
                mimetype: "audio/mp4", 
                ptt: true,
                caption: `🎵 تم تحميل: *${video.title}*\n🔗 الرابط: ${video.url}`
              }, { quoted: msg });
            } else {
              throw new Error("فشلت جميع محاولات التحميل.");
            }
          } catch (err) {
            await sock.sendMessage(from, { text: `❌ فشل البحث أو التحميل: ${err.message}` }, { quoted: msg });
          }
          break;

        case "راقب":
          if (!isDeveloper && !isOwner) return;
          if (!from.endsWith("@g.us")) return await sock.sendMessage(from, { text: "❌ هذا الأمر للمجموعات فقط." }, { quoted: msg });
          db.prepare("INSERT OR REPLACE INTO group_settings (jid, forbidden_words_enabled) VALUES (?, 1) ON CONFLICT(jid) DO UPDATE SET forbidden_words_enabled=1").run(from);
          await sock.sendMessage(from, { text: "✅ تم تفعيل مراقبة الكلمات المحظورة في هذه المجموعة." }, { quoted: msg });
          break;

        case "الغي":
          if (!isDeveloper && !isOwner) return;
          if (!from.endsWith("@g.us")) return await sock.sendMessage(from, { text: "❌ هذا الأمر للمجموعات فقط." }, { quoted: msg });
          db.prepare("INSERT OR REPLACE INTO group_settings (jid, forbidden_words_enabled) VALUES (?, 0) ON CONFLICT(jid) DO UPDATE SET forbidden_words_enabled=0").run(from);
          await sock.sendMessage(from, { text: "✅ تم تعطيل مراقبة الكلمات المحظورة في هذه المجموعة." }, { quoted: msg });
          break;

        case "المحظور":
          if (!from.endsWith("@g.us")) return await sock.sendMessage(from, { text: "❌ هذا الأمر للمجموعات فقط." }, { quoted: msg });
          const forbiddenCount = db.prepare("SELECT COUNT(*) as count FROM forbidden_words WHERE group_id = ?").get(from) as any;
          await sock.sendMessage(from, { text: `🛡️ عدد الكلمات المحظورة في هذه المجموعة: ${forbiddenCount.count}` }, { quoted: msg });
          break;

        case "ضيف":
          if (!isDeveloper && !isOwner) return;
          const wordToAdd = args[0];
          if (!wordToAdd) return await sock.sendMessage(from, { text: "❌ يرجى كتابة الكلمة المراد مراقبتها." }, { quoted: msg });
          db.prepare("INSERT OR REPLACE INTO forbidden_words (word, group_id) VALUES (?, ?)").run(wordToAdd, from);
          await sock.sendMessage(from, { text: `✅ تم إضافة "${wordToAdd}" لقائمة الكلمات المحظورة.` }, { quoted: msg });
          break;

        case "محو":
          if (!isDeveloper && !isOwner) return;
          const wordToRemove = args[0];
          if (!wordToRemove) return await sock.sendMessage(from, { text: "❌ يرجى كتابة الكلمة المراد إزالتها." }, { quoted: msg });
          db.prepare("DELETE FROM forbidden_words WHERE word = ? AND group_id = ?").run(wordToRemove, from);
          await sock.sendMessage(from, { text: `✅ تم إزالة "${wordToRemove}" من قائمة المراقبة.` }, { quoted: msg });
          break;

        case "انشئ":
          if (!isDeveloper && !isOwner) return;
          try {
            await sock.sendMessage(from, { text: "⏳ جاري إنشاء المجموعة وتجهيزها..." }, { quoted: msg });
            
            // 1. Create Group
            const group = await sock.groupCreate("مزروف ⚚ VENRO", [sender]);
            const groupId = group.id;
            
            // 2. Set Profile Picture
            try {
              const imgResponse = await axios.get("https://files.catbox.moe/k5s3wl.jpg", { responseType: 'arraybuffer' });
              await sock.updateProfilePicture(groupId, Buffer.from(imgResponse.data));
            } catch (e) {
              addLog(`فشل تعيين صورة المجموعة الجديدة: ${e}`);
            }
            
            // 3. Get Invite Link
            const inviteCode = await sock.groupInviteCode(groupId);
            const inviteUrl = `https://chat.whatsapp.com/${inviteCode}`;
            
            await sock.sendMessage(from, { 
              text: `✅ تم إنشاء المجموعة بنجاح!\n\n🔗 الرابط: ${inviteUrl}\n\nنورت الجحيم يا بطل. 🛡️` 
            }, { quoted: msg });
            
          } catch (err) {
            addLog(`خطأ في إنشاء المجموعة: ${err}`);
            await sock.sendMessage(from, { text: `❌ فشل إنشاء المجموعة: ${err.message || err}` }, { quoted: msg });
          }
          break;

        case "اكس":
          if (!from.endsWith("@g.us")) {
            await sock.sendMessage(from, { text: "❌ هذه اللعبة للمجموعات فقط." }, { quoted: msg });
            break;
          }
          const opponent = msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
          if (!opponent) {
            await sock.sendMessage(from, { text: "❌ يرجى منشن الشخص الذي تريد اللعب معه.\nمثال: .اكس @منشن" }, { quoted: msg });
            break;
          }
          
          if (tictactoeGames[from]) {
            await sock.sendMessage(from, { text: "❌ هناك لعبة جارية بالفعل في هذه المجموعة." }, { quoted: msg });
            break;
          }

          tictactoeGames[from] = {
            board: ["1", "2", "3", "4", "5", "6", "7", "8", "9"],
            turn: sender,
            players: [sender, opponent],
            symbols: ["❌", "⭕"]
          };

          const startMsg = `🎮 *تحدي VENRO X-O*\n\n` +
                           `👤 اللاعب 1: @${sender.split("@")[0]} (❌)\n` +
                           `👤 اللاعب 2: @${opponent.split("@")[0]} (⭕)\n\n` +
                           `الدور الآن عند: @${sender.split("@")[0]}\n` +
                           `اكتب الرقم (1-9) للعب.`;
          
          await sock.sendMessage(from, { text: startMsg, mentions: [sender, opponent] });
          break;

        case "تعديل":
            if (args[0] === "اسم" && args.slice(1).length > 0) {
                const newName = args.slice(1).join(" ");
                await sock.updateProfileName(newName);
                await sock.sendMessage(from, { text: `✅ تم تغيير الاسم إلى: ${newName}` }, { quoted: msg });
            } else if (args[0] === "صورة") {
                await sock.sendMessage(from, { text: "⚠️ ميزة تعديل الصورة تتطلب معالجة الميديا وهي قيد التحسين." }, { quoted: msg });
            }
            break;

        case "رفع": // Promote
            if (from.endsWith("@g.us")) {
                let target = msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                             msg.message.extendedTextMessage?.contextInfo?.participant;
                
                if (!target && args[0]) {
                    target = args[0].includes("@") ? args[0] : `${args[0]}@s.whatsapp.net`;
                }

                if (target) {
                    await sock.groupParticipantsUpdate(from, [target], "promote");
                    await sock.sendMessage(from, { text: `🔼 تم رفع @${target.split("@")[0]} لمشرف.`, mentions: [target] }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, { text: "❌ يرجى منشن الشخص أو الرد على رسالته لرفعه." }, { quoted: msg });
                }
            }
            break;

        case "تنزيل": // Demote
            if (from.endsWith("@g.us")) {
                let target = msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                             msg.message.extendedTextMessage?.contextInfo?.participant;
                
                if (!target && args[0]) {
                    target = args[0].includes("@") ? args[0] : `${args[0]}@s.whatsapp.net`;
                }

                if (target) {
                    await sock.groupParticipantsUpdate(from, [target], "demote");
                    await sock.sendMessage(from, { text: `🔽 تم تنزيل @${target.split("@")[0]} من المشرفين.`, mentions: [target] }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, { text: "❌ يرجى منشن الشخص أو الرد على رسالته لتنزيله." }, { quoted: msg });
                }
            }
            break;

        case "طرد": // Kick
            if (from.endsWith("@g.us")) {
                try {
                    const metadata = await sock.groupMetadata(from);
                    const botParticipant = metadata.participants.find(p => jidNormalizedUser(p.id) === botId);
                    const isBotAdmin = botParticipant?.admin === "admin" || botParticipant?.admin === "superadmin";

                    if (!isBotAdmin) {
                        await sock.sendMessage(from, { text: "❌ عذراً، يجب أن يكون البوت مشرفاً (Admin) ليتمكن من طرد الأعضاء." }, { quoted: msg });
                        break;
                    }

                    let target = msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                                 msg.message.extendedTextMessage?.contextInfo?.participant;
                    
                    if (!target && args[0]) {
                        target = args[0].includes("@") ? args[0] : `${args[0]}@s.whatsapp.net`;
                    }

                    if (target) {
                        await sock.groupParticipantsUpdate(from, [target], "remove");
                        await sock.sendMessage(from, { text: `🚪 تم طرد @${target.split("@")[0]} من المجموعة.`, mentions: [target] }, { quoted: msg });
                    } else {
                        await sock.sendMessage(from, { text: "❌ يرجى منشن الشخص أو الرد على رسالته لطرده." }, { quoted: msg });
                    }
                } catch (err) {
                    addLog(`خطأ في الطرد: ${err}`);
                    await sock.sendMessage(from, { text: "❌ حدث خطأ أثناء محاولة الطرد." }, { quoted: msg });
                }
            }
            break;

        case "اضف":
        case "إضافة":
            if (args[0]) {
                const quotedText = msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.conversation || 
                                 msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.extendedTextMessage?.text;
                if (quotedText) {
                    db.prepare("INSERT OR REPLACE INTO custom_commands (name, response, bot_id) VALUES (?, ?, ?)").run(args[0], quotedText, botNumber);
                    await sock.sendMessage(from, { text: `✅ تم إضافة الأمر .${args[0]} بنجاح للرقم ${botNumber}. 👑\n\nيمكنك الآن استخدامه بكتابة .${args[0]}` }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, { text: "❌ يرجى الرد على الرسالة التي تحتوي على كود أو رد الأمر." }, { quoted: msg });
                }
            } else {
                await sock.sendMessage(from, { text: "❌ يرجى كتابة اسم الأمر الجديد.\nمثال: .اضف مرحبا (مع الرد على النص)" }, { quoted: msg });
            }
            break;

        case "فتح":
          if (args[0]) {
            const builtInCommands: Record<string, string> = {
              "فينرو": "أمر فحص حالة البوت والتحقق من الاتصال.",
              "دردشه": "تفعيل وضع الذكاء الاصطناعي (Gemini) للرد التلقائي.",
              "توقف": "إيقاف وضع الذكاء الاصطناعي والعودة لنظام الأوامر.",
              "اوامر": "عرض قائمة بجميع الأوامر المتاحة في البوت.",
              "ايدي": "عرض المعرف الخاص بالمستخدم (JID).",
              "مطور": "إضافة مطورين جدد للتحكم في البوت.",
              "حظر": "حظر رقم معين من التواصل مع البوت.",
              "بلغ": "إرسال بلاغات سبام حقيقية لرقم معين (بحد أقصى 20).",
              "تعديل": "تعديل بيانات الحساب مثل الاسم أو الصورة.",
              "رفع": "ترقية عضو في المجموعة إلى رتبة مشرف.",
              "تنزيل": "إزالة رتبة المشرف من عضو في المجموعة.",
              "طرد": "إزالة عضو من المجموعة.",
              "إضافة": "إضافة أمر مخصص جديد للبوت."
            };

            const cmd = db.prepare("SELECT response FROM custom_commands WHERE name = ? AND bot_id = ?").get(args[0], botNumber);
            
            if (cmd) {
              await sock.sendMessage(from, { text: `📄 كود الأمر المخصص .${args[0]}:\n\n${cmd.response}` }, { quoted: msg });
            } else if (builtInCommands[args[0]]) {
              await sock.sendMessage(from, { text: `🛠️ *أمر نظام داخلي: .${args[0]}*\n\nالوصف: ${builtInCommands[args[0]]}\n\n_ملاحظة: هذا الأمر جزء من نظام VENRO الأساسي ولا يمكن تعديله._` }, { quoted: msg });
            } else {
              await sock.sendMessage(from, { text: "❌ الأمر غير موجود في النظام أو الأوامر المخصصة لهذا الرقم." }, { quoted: msg });
            }
          }
          break;

        default:
          // Tic-Tac-Toe Move Handler
          if (tictactoeGames[from] && !isNaN(parseInt(command)) && parseInt(command) >= 1 && parseInt(command) <= 9) {
            const game = tictactoeGames[from];
            if (sender !== game.turn) break;

            const move = parseInt(command) - 1;
            if (game.board[move] === "❌" || game.board[move] === "⭕") {
              await sock.sendMessage(from, { text: "❌ هذا المكان محجوز بالفعل!" }, { quoted: msg });
              break;
            }

            const symbol = game.players[0] === sender ? game.symbols[0] : game.symbols[1];
            game.board[move] = symbol;

            // Check Winner
            const winPatterns = [
              [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
              [0, 3, 6], [1, 4, 7], [2, 5, 8], // Cols
              [0, 4, 8], [2, 4, 6]             // Diagonals
            ];

            let winner = null;
            for (const pattern of winPatterns) {
              if (game.board[pattern[0]] === symbol && game.board[pattern[1]] === symbol && game.board[pattern[2]] === symbol) {
                winner = sender;
                break;
              }
            }

            const renderBoard = () => {
              let b = game.board.map(s => {
                if (s === "❌") return "❌";
                if (s === "⭕") return "⭕";
                const emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"];
                return emojis[parseInt(s) - 1];
              });
              return `${b[0]}${b[1]}${b[2]}\n${b[3]}${b[4]}${b[5]}\n${b[6]}${b[7]}${b[8]}`;
            };

            if (winner) {
              await sock.sendMessage(from, { 
                text: `🎉 *مبروك الفوز!* 🎉\n\n${renderBoard()}\n\nالفائز: @${sender.split("@")[0]}\n#VENRO_CHAMPION`,
                mentions: [sender]
              });
              delete tictactoeGames[from];
            } else if (!game.board.some(s => !isNaN(parseInt(s)))) {
              await sock.sendMessage(from, { text: `🤝 *تعادل!* 🤝\n\n${renderBoard()}\n\nانتهت اللعبة بالتعادل.` });
              delete tictactoeGames[from];
            } else {
              game.turn = game.players.find(p => p !== sender)!;
              await sock.sendMessage(from, { 
                text: `🎮 *تحدي VENRO X-O*\n\n${renderBoard()}\n\nالدور الآن عند: @${game.turn.split("@")[0]}`,
                mentions: [game.turn]
              });
            }
            break;
          }

          const custom = db.prepare("SELECT response FROM custom_commands WHERE name = ? AND bot_id = ?").get(command, botNumber);
          if (custom) {
            await sock.sendMessage(from, { text: custom.response }, { quoted: msg });
          }
          break;
      }
    } else if (aiChatUsers.has(from)) {
      // Gemini AI Chat
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: text,
        });
        await sock.sendMessage(from, { text: response.text }, { quoted: msg });
      } catch (err) {
        addLog(`AI Error: ${err}`);
      }
    }
  });
}

// API Endpoints
app.get("/api/bot/status", (req, res) => {
  res.json({ status: botStatus, pairingCode });
});

app.get("/api/logs", (req, res) => {
  try {
    const logs = db.prepare("SELECT * FROM logs ORDER BY timestamp DESC LIMIT 50").all();
    res.json(logs);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch logs" });
  }
});

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.post("/api/bot/start", async (req, res) => {
  try {
    const { phoneNumber } = req.body;
    
    if (sock && botStatus === "connected") {
      addLog("ℹ️ البوت متصل بالفعل، سيتم تجاهل طلب التشغيل.");
      return res.json({ status: "connected" });
    }

    if (!phoneNumber && botStatus === "stopped") {
      // Try to auto-resume if no number provided but session exists
      const authPath = path.join(__dirname, "auth_info");
      if (fs.existsSync(authPath)) {
        addLog("🔄 محاولة استئناف الجلسة المحفوظة...");
        await startBot("");
        return res.json({ status: "starting" });
      }
      return res.status(400).json({ error: "Phone number required" });
    }

    await startBot(phoneNumber || "");
    res.json({ status: "starting" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/bot/stop", (req, res) => {
  try {
    if (sock) {
      manualStop = true;
      // Use end() instead of logout() to preserve the session for next time
      sock.end(undefined); 
      sock = null;
      botStatus = "stopped";
      pairingCode = null;
      addLog("تم إيقاف البوت بواسطة المستخدم (تم حفظ الجلسة).");
    }
    res.json({ status: "stopped" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/bot/clear", async (req, res) => {
  addLog("⏳ جاري بدء عملية تنظيف الجلسة...");
  try {
    botStatus = "stopped";
    pairingCode = null;

    if (sock) {
      try {
        sock.end(undefined);
      } catch (e) {}
      sock = null;
    }
    
    // Wait a bit for the socket to close
    await new Promise(resolve => setTimeout(resolve, 1000));

    const authPath = path.join(__dirname, "auth_info");
    if (fs.existsSync(authPath)) {
      try {
        fs.rmSync(authPath, { recursive: true, force: true });
        addLog("✅ تم حذف ملفات الجلسة (auth_info) بنجاح.");
      } catch (e) {
        addLog(`⚠️ فشل حذف بعض ملفات الجلسة: ${e.message}`);
      }
    } else {
      addLog("ℹ️ لم يتم العثور على مجلد الجلسة، الجلسة نظيفة بالفعل.");
    }
    
    addLog("✨ تم تنظيف الجلسة بالكامل. يمكنك الآن الربط من جديد.");
    res.json({ status: "cleared" });
  } catch (err) {
    addLog(`❌ فشل في تنظيف الجلسة: ${err.message}`);
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/commands", (req, res) => {
  try {
    const botNumber = sock?.user?.id?.split(":")[0]?.split("@")[0];
    if (!botNumber) return res.json([]);
    const commands = db.prepare("SELECT name, response FROM custom_commands WHERE bot_id = ?").all(botNumber);
    res.json(commands);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch commands" });
  }
});

app.post("/api/commands/add", (req, res) => {
  const { name, response } = req.body;
  if (!name || !response) return res.status(400).json({ error: "Name and response required" });
  try {
    const botNumber = sock?.user?.id?.split(":")[0]?.split("@")[0];
    if (!botNumber) return res.status(400).json({ error: "Bot must be connected to add commands" });
    
    db.prepare("INSERT OR REPLACE INTO custom_commands (name, response, bot_id) VALUES (?, ?, ?)").run(name, response, botNumber);
    addLog(`تم إضافة أمر مخصص جديد من الموقع للرقم ${botNumber}: .${name}`);
    res.json({ status: "ok" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/api/commands/:name", (req, res) => {
  const { name } = req.params;
  try {
    const botNumber = sock?.user?.id?.split(":")[0]?.split("@")[0];
    if (!botNumber) return res.status(400).json({ error: "Bot must be connected to delete commands" });
    
    db.prepare("DELETE FROM custom_commands WHERE name = ? AND bot_id = ?").run(name, botNumber);
    addLog(`تم حذف الأمر المخصص للرقم ${botNumber}: .${name}`);
    res.json({ status: "ok" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Catch-all for missing API routes to prevent Vite HTML fallback
app.all("/api/*", (req, res) => {
  res.status(404).json({ error: "API route not found" });
});

async function init() {
  // Start listening immediately so the API is available
  const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`)) => {
    console.log(`Server running on http://localhost:${PORT}`);
    addLog("🚀 تم تشغيل خادم البوت بنجاح.");
  });

  // Auto-start bot if session exists and is valid
  try {
    const authPath = path.join(__dirname, "auth_info");
    if (fs.existsSync(authPath)) {
      addLog("تم العثور على مجلد الجلسة، جاري محاولة التشغيل التلقائي...");
      startBot("").catch(e => {
        addLog(`❌ فشل التشغيل التلقائي للبوت: ${e.message}`);
      });
    }
  } catch (e) {
    addLog("⚠️ خطأ أثناء التحقق من مجلد الجلسة عند بدء الخادم.");
  }

  // Vite middleware for development - MUST be last to not interfere with API
  try {
    if (process.env.NODE_ENV !== "production") {
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      });
      app.use(vite.middlewares);
    } else {
      // Production static files
      const distPath = path.join(__dirname, "dist");
      if (fs.existsSync(distPath)) {
        app.use(express.static(distPath));
        app.get("*", (req, res) => {
          res.sendFile(path.join(distPath, "index.html"));
        });
      } else {
        addLog("⚠️ تحذير: مجلد dist غير موجود. يرجى تشغيل npm run build.");
      }
    }
  } catch (e) {
    addLog(`❌ فشل إعداد واجهة المستخدم (Vite/Static): ${e.message}`);
  }
}

init();
