import React, { useState, useEffect, useRef } from "react";
import { 
  Shield, 
  Terminal, 
  Power, 
  PowerOff, 
  MessageSquare, 
  Code, 
  UserPlus, 
  AlertCircle,
  CheckCircle2,
  Loader2,
  Hash,
  RefreshCw
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Log {
  id: number;
  message: string;
  timestamp: string;
}

export default function App() {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [status, setStatus] = useState<"stopped" | "starting" | "connected" | "connecting">("stopped");
  const [pairingCode, setPairingCode] = useState<string | null>(null);
  const [logs, setLogs] = useState<Log[]>([]);
  const [customCommands, setCustomCommands] = useState<{name: string, response: string}[]>([]);
  const [loadingStart, setLoadingStart] = useState(false);
  const [loadingStop, setLoadingStop] = useState(false);
  const [loadingClear, setLoadingClear] = useState(false);
  const [loadingGenerate, setLoadingGenerate] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  const fetchStatus = async () => {
    try {
      const res = await fetch("/api/bot/status");
      const data = await res.json();
      setStatus(data.status);
      setPairingCode(data.pairingCode);
    } catch (err) {
      console.error("Failed to fetch status", err);
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch("/api/logs");
      const data = await res.json();
      if (Array.isArray(data)) {
        setLogs(data);
      }
    } catch (err) {
      console.error("Failed to fetch logs", err);
    }
  };

  const fetchCommands = async () => {
    try {
      const res = await fetch("/api/commands");
      const data = await res.json();
      if (Array.isArray(data)) {
        setCustomCommands(data);
      }
    } catch (err) {
      console.error("Failed to fetch commands", err);
    }
  };

  useEffect(() => {
    fetchStatus();
    fetchLogs();
    fetchCommands();
    const interval = setInterval(() => {
      fetchStatus();
      fetchLogs();
      fetchCommands();
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Removed automatic scroll to bottom to prevent jumping when user scrolls up
  // useEffect(() => {
  //   logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  // }, [logs]);

  const handleStart = async () => {
    if (!phoneNumber) return;
    setLoadingStart(true);
    try {
      await fetch("/api/bot/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneNumber }),
      });
      addLocalLog(`جاري تشغيل البوت للرقم: ${phoneNumber}...`);
    } catch (err) {
      addLocalLog("خطأ في تشغيل البوت.");
    } finally {
      setLoadingStart(false);
    }
  };

  const handleStop = async () => {
    setLoadingStop(true);
    try {
      await fetch("/api/bot/stop", { method: "POST" });
      addLocalLog("تم إيقاف البوت.");
    } catch (err) {
      addLocalLog("خطأ في إيقاف البوت.");
    } finally {
      setLoadingStop(false);
    }
  };

  const addLocalLog = (msg: string) => {
    setLogs(prev => [{ id: Date.now(), message: msg, timestamp: new Date().toISOString() }, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 font-sans selection:bg-emerald-500/30">
      {/* Header / Branding */}
      <header className="border-b border-white/5 bg-black/40 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Shield className="text-black w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tighter text-white">VENRO</h1>
              <p className="text-[10px] uppercase tracking-[0.2em] text-emerald-500 font-bold">WhatsApp Bot System</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-2 ${
              status === "connected" ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" :
              status === "stopped" ? "bg-red-500/10 text-red-500 border border-red-500/20" :
              "bg-amber-500/10 text-amber-500 border border-amber-500/20 animate-pulse"
            }`}>
              <div className={`w-1.5 h-1.5 rounded-full ${
                status === "connected" ? "bg-emerald-500" :
                status === "stopped" ? "bg-red-500" : "bg-amber-500"
              }`} />
              {status === "connected" ? "متصل" : status === "stopped" ? "متوقف" : "جاري الربط"}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Control Panel */}
        <div className="lg:col-span-5 space-y-8">
          <section className="bg-[#141414] border border-white/5 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 blur-3xl rounded-full -mr-16 -mt-16" />
            
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Power className="w-5 h-5 text-emerald-500" />
              لوحة التحكم
            </h2>

            <div className="space-y-6">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-2 ml-1">رقم الهاتف (مع كود الدولة)</label>
                <div className="relative">
                  <Hash className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input 
                    type="text" 
                    placeholder="201112656906"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    disabled={status !== "stopped"}
                    className="w-full bg-black border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-emerald-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={handleStart}
                  disabled={status === "connected" || status === "connecting" || status === "starting" || !phoneNumber || loadingStart || loadingStop || loadingClear}
                  className="flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 disabled:bg-gray-800 text-black font-bold py-4 rounded-2xl transition-all active:scale-95 shadow-lg shadow-emerald-500/10"
                >
                  {loadingStart || status === "connecting" || status === "starting" ? <Loader2 className="w-5 h-5 animate-spin" /> : <Power className="w-5 h-5" />}
                  {status === "connecting" || status === "starting" ? "جاري الاتصال" : "تشغيل البوت"}
                </button>
                <button 
                  onClick={handleStop}
                  disabled={status === "stopped" || loadingStart || loadingStop || loadingClear}
                  className="flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 disabled:opacity-50 text-white font-bold py-4 rounded-2xl border border-white/10 transition-all active:scale-95"
                >
                  {loadingStop ? <Loader2 className="w-5 h-5 animate-spin" /> : <PowerOff className="w-5 h-5" />}
                  إيقاف
                </button>
              </div>

              {status !== "connected" && (
                <button 
                  onClick={async () => {
                    setLoadingClear(true);
                    addLocalLog("⏳ جاري إرسال طلب تنظيف الجلسة للسيرفر...");
                    try {
                      const response = await fetch("/api/bot/clear", { method: "POST" });
                      if (!response.ok) throw new Error("فشل الرد من السيرفر");
                      
                      // Refresh logs and status immediately
                      await fetchLogs();
                      await fetchStatus();
                      setPairingCode(null);
                      setPhoneNumber("");
                      addLocalLog("✨ تم تنظيف الجلسة بنجاح. يمكنك الآن إدخال الرقم والربط من جديد.");
                      setLoadingClear(false);
                    } catch (e) {
                      addLocalLog(`❌ فشل تنظيف الجلسة: ${(e as Error).message}`);
                      alert("فشل تنظيف الجلسة: " + (e as Error).message);
                      setLoadingClear(false);
                    }
                  }}
                  disabled={loadingStart || loadingStop || loadingClear}
                  className="w-full py-4 bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/20 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                >
                  {loadingClear ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      جاري التنظيف...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-5 h-5" />
                      تنظيف الجلسة وإعادة المحاولة
                    </>
                  )}
                </button>
              )}

              <AnimatePresence mode="wait">
                {status === "starting" && !pairingCode && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="bg-white/5 border border-white/10 rounded-3xl p-8 text-center"
                  >
                    <Loader2 className="w-8 h-8 text-emerald-500 animate-spin mx-auto mb-4" />
                    <p className="text-sm font-bold text-gray-400">جاري طلب كود الربط من واتساب...</p>
                    <p className="text-[10px] text-gray-600 mt-2">قد يستغرق هذا بضع ثوانٍ، يرجى الانتظار</p>
                  </motion.div>
                )}

                {pairingCode && (
                  <motion.div 
                    key="pairing-box"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="relative group"
                  >
                    <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                    <div className="relative bg-[#0a0a0a] border border-emerald-500/30 rounded-3xl p-8 text-center">
                      <div className="flex items-center justify-center gap-2 mb-4">
                        <Shield className="w-4 h-4 text-emerald-500" />
                        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-emerald-500">Pairing Authorization</p>
                      </div>
                      
                      <div className="flex items-center justify-center gap-3 mb-6">
                        {typeof pairingCode === "string" && pairingCode.split("").map((char, i) => (
                          <div key={i} className="w-10 h-14 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center text-3xl font-black text-white shadow-inner">
                            {char}
                          </div>
                        ))}
                      </div>

                      <div className="space-y-3">
                        <p className="text-[11px] text-gray-400 leading-relaxed">
                          أدخل هذا الكود في واتساب لإتمام عملية الربط بنجاح
                        </p>
                        <div className="flex items-center justify-center gap-4 text-[9px] text-emerald-500/40 font-bold uppercase tracking-widest">
                          <span>Secure Connection</span>
                          <div className="w-1 h-1 rounded-full bg-emerald-500/20" />
                          <span>Encrypted Session</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </section>

          {/* Quick Info */}
          <section className="grid grid-cols-2 gap-4">
            <div className="bg-[#141414] border border-white/5 rounded-3xl p-6">
              <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center mb-4">
                <MessageSquare className="text-blue-500 w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">نظام الدردشة</h3>
              <p className="text-xs text-gray-500 mt-1">مدعوم بـ Gemini AI للرد التلقائي.</p>
            </div>
            <div className="bg-[#141414] border border-white/5 rounded-3xl p-6">
              <div className="w-10 h-10 bg-purple-500/10 rounded-xl flex items-center justify-center mb-4">
                <Code className="text-purple-500 w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">الأوامر المخصصة</h3>
              <p className="text-xs text-gray-500 mt-1">إضافة أوامر جديدة عبر الموقع أو الواتساب.</p>
            </div>
          </section>

          {/* New Section: Add Custom Commands */}
          <section className="bg-[#141414] border border-white/5 rounded-3xl p-8 shadow-2xl space-y-8">
            <div>
              <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <Code className="w-5 h-5 text-emerald-500" />
                إضافة أمر مخصص
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">اسم الأمر (بدون نقطة)</label>
                  <input 
                    id="cmd-name"
                    type="text" 
                    placeholder="مثال: مرحبا"
                    className="w-full bg-black border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-emerald-500/50 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">رد البوت</label>
                  <textarea 
                    id="cmd-response"
                    placeholder="اكتب الرد الذي سيقوم البوت بإرساله..."
                    rows={3}
                    className="w-full bg-black border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-emerald-500/50 transition-all resize-none"
                  />
                </div>
                <button 
                  onClick={async () => {
                    const name = (document.getElementById("cmd-name") as HTMLInputElement).value;
                    const response = (document.getElementById("cmd-response") as HTMLTextAreaElement).value;
                    if (!name || !response) return alert("يرجى ملء جميع الحقول");
                    
                    try {
                      const res = await fetch("/api/commands/add", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ name, response }),
                      });
                      if (res.ok) {
                        alert("✅ تم إضافة الأمر بنجاح!");
                        (document.getElementById("cmd-name") as HTMLInputElement).value = "";
                        (document.getElementById("cmd-response") as HTMLTextAreaElement).value = "";
                        fetchCommands();
                      }
                    } catch (e) {
                      alert("❌ فشل إضافة الأمر");
                    }
                  }}
                  className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-xl transition-all active:scale-95"
                >
                  حفظ الأمر الجديد
                </button>
              </div>
            </div>

            {/* List of Custom Commands */}
            <div className="pt-8 border-t border-white/5">
              <h2 className="text-sm font-bold text-gray-400 mb-4 uppercase tracking-widest">الأوامر المضافة حالياً</h2>
              {status !== "connected" ? (
                <div className="bg-yellow-500/10 border border-yellow-500/20 p-4 rounded-xl">
                  <p className="text-[10px] text-yellow-500 text-center">⚠️ يرجى ربط البوت أولاً لعرض وإدارة الأوامر المخصصة الخاصة برقمك.</p>
                  <p className="text-[9px] text-yellow-500/60 text-center mt-1">تنبيه: كثرة طلب كود الربط في وقت قصير قد تؤدي لحظر مؤقت من واتساب (تعذر الربط).</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-60 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/5">
                  {customCommands.length === 0 ? (
                    <p className="text-[10px] text-gray-600 italic">لا توجد أوامر مخصصة لهذا الرقم بعد.</p>
                  ) : (
                    customCommands.map((cmd) => (
                      <div key={cmd.name} className="flex items-center justify-between bg-black/40 border border-white/5 p-3 rounded-xl group hover:border-white/20 transition-all">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center text-[10px] font-bold text-emerald-500">.{cmd.name}</div>
                          <p className="text-[10px] text-gray-400 truncate max-w-[150px]">{cmd.response}</p>
                        </div>
                        <button 
                          onClick={async () => {
                            if (!confirm(`هل أنت متأكد من حذف الأمر .${cmd.name}؟`)) return;
                            try {
                              const res = await fetch(`/api/commands/${cmd.name}`, { method: "DELETE" });
                              if (res.ok) fetchCommands();
                            } catch (e) {
                              alert("❌ فشل الحذف");
                            }
                          }}
                          className="p-2 text-gray-600 hover:text-red-500 transition-colors"
                        >
                          <PowerOff className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </section>
        </div>

        {/* Right Column: Logs / Terminal */}
        <div className="lg:col-span-7">
          <section className="bg-[#0f0f0f] border border-white/5 rounded-3xl flex flex-col h-[600px] shadow-2xl overflow-hidden ring-1 ring-white/5">
            <div className="bg-black/40 px-6 py-4 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Terminal className="w-4 h-4 text-emerald-500" />
                <span className="text-xs font-bold uppercase tracking-widest text-gray-400">سجل العمليات (Terminal)</span>
              </div>
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500/40" />
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500/20 border border-amber-500/40" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/20 border border-emerald-500/40" />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 font-mono text-sm space-y-2 scrollbar-thin scrollbar-thumb-white/10 scroll-smooth">
              {logs.length === 0 ? (
                <div className="text-gray-600 italic">في انتظار العمليات...</div>
              ) : (
                [...logs].reverse().map((log) => (
                  <div key={log.id} className="flex gap-4 group">
                    <span className="text-gray-700 shrink-0 select-none">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                    <span className={`
                      ${log.message.includes("Error") || log.message.includes("خطأ") ? "text-red-400" : 
                        log.message.includes("connected") || log.message.includes("نجاح") ? "text-emerald-400" : 
                        log.message.includes("Pairing") ? "text-amber-400" : "text-gray-300"}
                    `}>
                      {log.message}
                    </span>
                  </div>
                ))
              )}
            </div>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-white/5 mt-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="text-center md:text-left">
            <h2 className="text-4xl font-black text-white/10 tracking-tighter mb-2">VENRO</h2>
            <p className="text-xs text-gray-600 font-medium">جميع الحقوق محفوظة © {new Date().getFullYear()} VENRO System</p>
          </div>
          
          <div className="flex gap-12">
            <div className="text-center md:text-left">
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-emerald-500 mb-4">المطور</h4>
              <p className="text-sm text-gray-400 font-medium">VENRO EL-HAKEM</p>
            </div>
            <div className="text-center md:text-left">
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-emerald-500 mb-4">الإصدار</h4>
              <p className="text-sm text-gray-400 font-medium">v2.4.0 Stable</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
